import { useNavigate } from "react-router-dom";

export default function PrivacyPolicy() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-lighter to-dark-darker">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,215,0,0.1),transparent_50%)]" />

      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-gold hover:text-gold-light transition-colors"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          Back
        </button>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-gold to-electric rounded-xl flex items-center justify-center text-xl">
            🔒
          </div>
          <h1 className="text-xl font-display font-bold text-gold">
            Privacy Policy
          </h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 pb-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-card-glass rounded-2xl p-8 border border-border/50 shadow-card-soft">
            <div className="prose prose-invert max-w-none">
              <h2 className="text-3xl font-display font-bold text-gold mb-6">
                Privacy Policy for Football Routine
              </h2>

              <p className="text-dark-foreground/80 mb-6">
                <strong>Effective Date:</strong>{" "}
                {new Date().toLocaleDateString()}
              </p>

              <div className="space-y-8">
                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    1. Information We Collect
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      Football Routine is designed to protect your privacy. The
                      app stores information locally on your device:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Game progress and scores</li>
                      <li>Coins earned and spent</li>
                      <li>Level completion status</li>
                      <li>Purchased items and power-ups</li>
                      <li>App settings and preferences</li>
                    </ul>
                    <p>
                      <strong>No personal information</strong> such as names,
                      email addresses, or contact details are collected or
                      stored.
                    </p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    2. How We Use Your Information
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>The locally stored data is used to:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Save your game progress between sessions</li>
                      <li>Track your coin balance and purchases</li>
                      <li>Unlock new levels based on your performance</li>
                      <li>Maintain your app settings and preferences</li>
                      <li>Provide a personalized gaming experience</li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    3. Data Storage and Security
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      All your data is stored locally on your device using
                      browser localStorage. This means:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Your data never leaves your device</li>
                      <li>No data is transmitted to external servers</li>
                      <li>You have full control over your information</li>
                      <li>
                        Data is automatically protected by your device's
                        security
                      </li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    4. Third-Party Services
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      Football Routine does not integrate with any third-party
                      analytics, advertising, or tracking services. The app
                      operates entirely offline after initial loading.
                    </p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    5. Children's Privacy
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      Football Routine is appropriate for users of all ages.
                      Since no personal information is collected, there are no
                      special privacy concerns regarding children's use of the
                      app.
                    </p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    6. Your Rights
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>You have the right to:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>
                        Clear your data at any time through the Settings page
                      </li>
                      <li>Reset your progress and start fresh</li>
                      <li>
                        Stop using the app without any data retention concerns
                      </li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    7. Changes to This Policy
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      We may update this Privacy Policy from time to time. Any
                      changes will be reflected on this page with an updated
                      effective date.
                    </p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    8. Contact Information
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      If you have any questions about this Privacy Policy,
                      please contact the app owner: abatynawy
                    </p>
                  </div>
                </section>
              </div>

              <div className="mt-8 p-4 bg-dark-lighter rounded-xl border border-gold/20">
                <p className="text-center text-gold font-medium">
                  Your privacy is important to us. Football Routine is designed
                  with privacy by design principles.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Copyright Footer */}
      <footer className="relative z-10 p-6 text-center border-t border-border/20">
        <p className="text-dark-foreground/60 text-sm">
          © Copyright owned by abatynawy
        </p>
      </footer>
    </div>
  );
}
