import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  addCoinsToTotal,
  completeRoutine,
  updateStreak,
  updateUnlockedLevels,
} from "@shared/achievements";

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

const questionsByLevel: { [key: number]: Question[] } = {
  1: [
    // Level 1: Rookie - Basic football knowledge
    {
      id: 1,
      question:
        "How many players are on the field for each team during a match?",
      options: ["10", "11", "12", "9"],
      correctAnswer: 1,
      explanation: "Each team has 11 players on the field at any time.",
    },
    {
      id: 2,
      question: "What is the duration of a standard football match?",
      options: ["80 minutes", "90 minutes", "100 minutes", "120 minutes"],
      correctAnswer: 1,
      explanation: "A standard match is 90 minutes plus added time.",
    },
    {
      id: 3,
      question:
        "Which body part can't be used to touch the ball (except goalkeepers)?",
      options: ["Head", "Chest", "Hands", "Knee"],
      correctAnswer: 2,
      explanation:
        "Only goalkeepers can use their hands within the penalty area.",
    },
    {
      id: 4,
      question:
        "What is it called when a player scores three goals in one match?",
      options: ["Double", "Hat-trick", "Triple", "Perfect"],
      correctAnswer: 1,
      explanation:
        "A hat-trick is when a player scores three goals in one match.",
    },
    {
      id: 5,
      question: "How many substitutions can a team make in a match?",
      options: ["3", "5", "7", "Unlimited"],
      correctAnswer: 1,
      explanation: "Teams can make up to 5 substitutions in modern football.",
    },
    {
      id: 6,
      question: "What color card results in a player being sent off?",
      options: ["Yellow", "Red", "Blue", "Green"],
      correctAnswer: 1,
      explanation: "A red card means immediate dismissal from the match.",
    },
    {
      id: 7,
      question: "Which country hosts the Premier League?",
      options: ["Spain", "Italy", "England", "Germany"],
      correctAnswer: 2,
      explanation: "The Premier League is England's top football division.",
    },
    {
      id: 8,
      question:
        "What is the line called that the ball must completely cross to score?",
      options: ["Touch line", "Goal line", "Penalty line", "Corner line"],
      correctAnswer: 1,
      explanation: "The ball must completely cross the goal line for a goal.",
    },
    {
      id: 9,
      question: "How often is the FIFA World Cup held?",
      options: [
        "Every 2 years",
        "Every 4 years",
        "Every 5 years",
        "Every 3 years",
      ],
      correctAnswer: 1,
      explanation: "The FIFA World Cup is held every four years.",
    },
    {
      id: 10,
      question: "What is the standard size of a football team's squad?",
      options: ["18 players", "23 players", "25 players", "20 players"],
      correctAnswer: 1,
      explanation: "Most squads can have up to 23-25 players registered.",
    },
  ],
  2: [
    // Level 2: Amateur - Club-level football facts
    {
      id: 1,
      question: "Which Spanish club is known as 'Los Blancos'?",
      options: ["Barcelona", "Real Madrid", "Atletico Madrid", "Valencia"],
      correctAnswer: 1,
      explanation: "Real Madrid is nicknamed 'Los Blancos' (The Whites).",
    },
    {
      id: 2,
      question: "What is Manchester United's home stadium called?",
      options: ["Anfield", "Old Trafford", "Etihad Stadium", "Stamford Bridge"],
      correctAnswer: 1,
      explanation: "Old Trafford has been Manchester United's home since 1910.",
    },
    {
      id: 3,
      question: "Which Italian club is known as 'The Old Lady'?",
      options: ["AC Milan", "Inter Milan", "Juventus", "Roma"],
      correctAnswer: 2,
      explanation: "Juventus is nicknamed 'La Vecchia Signora' (The Old Lady).",
    },
    {
      id: 4,
      question: "What does 'FC' stand for in team names?",
      options: [
        "Football Club",
        "First Class",
        "Final Championship",
        "Fast Competition",
      ],
      correctAnswer: 0,
      explanation: "FC stands for Football Club.",
    },
    {
      id: 5,
      question: "Which German club has won the most Bundesliga titles?",
      options: [
        "Borussia Dortmund",
        "Bayern Munich",
        "Schalke 04",
        "Bayer Leverkusen",
      ],
      correctAnswer: 1,
      explanation: "Bayern Munich has won over 30 Bundesliga titles.",
    },
    {
      id: 6,
      question: "What is Liverpool FC's famous anthem?",
      options: [
        "Blue Moon",
        "You'll Never Walk Alone",
        "Glory Glory",
        "Sweet Caroline",
      ],
      correctAnswer: 1,
      explanation: "'You'll Never Walk Alone' is Liverpool's iconic anthem.",
    },
    {
      id: 7,
      question: "Which French club plays at the Parc des Princes?",
      options: ["Lyon", "Marseille", "Monaco", "Paris Saint-Germain"],
      correctAnswer: 3,
      explanation: "PSG's home stadium is the Parc des Princes in Paris.",
    },
    {
      id: 8,
      question: "What is Arsenal FC's nickname?",
      options: ["The Reds", "The Gunners", "The Blues", "The Saints"],
      correctAnswer: 1,
      explanation: "Arsenal are known as 'The Gunners'.",
    },
    {
      id: 9,
      question: "Which Brazilian club does Pelé have strong ties with?",
      options: ["Flamengo", "Corinthians", "Santos", "São Paulo"],
      correctAnswer: 2,
      explanation: "Pelé played most of his career at Santos FC.",
    },
    {
      id: 10,
      question: "What does 'El Clásico' refer to?",
      options: [
        "Madrid vs Atletico",
        "Barcelona vs Real Madrid",
        "Sevilla vs Betis",
        "Valencia vs Villarreal",
      ],
      correctAnswer: 1,
      explanation: "El Clásico is the match between Barcelona and Real Madrid.",
    },
  ],
  3: [
    // Level 3: Professional - League and tournament knowledge
    {
      id: 1,
      question: "Which player has won the most Ballon d'Or awards?",
      options: [
        "Cristiano Ronaldo",
        "Lionel Messi",
        "Michel Platini",
        "Johan Cruyff",
      ],
      correctAnswer: 1,
      explanation:
        "Lionel Messi has won 8 Ballon d'Or awards, the most in history.",
    },
    {
      id: 2,
      question: "Which country has won the most FIFA World Cups?",
      options: ["Germany", "Argentina", "Brazil", "Italy"],
      correctAnswer: 2,
      explanation:
        "Brazil has won 5 World Cups (1958, 1962, 1970, 1994, 2002).",
    },
    {
      id: 3,
      question: "Which club has won the most UEFA Champions League titles?",
      options: ["Barcelona", "AC Milan", "Liverpool", "Real Madrid"],
      correctAnswer: 3,
      explanation: "Real Madrid has won 14 UEFA Champions League titles.",
    },
    {
      id: 4,
      question: "Who scored the 'Hand of God' goal?",
      options: ["Pelé", "Diego Maradona", "Ronaldinho", "Garrincha"],
      correctAnswer: 1,
      explanation:
        "Maradona scored this controversial goal against England in 1986.",
    },
    {
      id: 5,
      question:
        "Which tournament is considered the most prestigious in European club football?",
      options: [
        "Europa League",
        "Champions League",
        "Conference League",
        "Super Cup",
      ],
      correctAnswer: 1,
      explanation:
        "The UEFA Champions League is the premier European competition.",
    },
    {
      id: 6,
      question: "Who holds the record for most international goals?",
      options: ["Pelé", "Cristiano Ronaldo", "Ali Daei", "Lionel Messi"],
      correctAnswer: 1,
      explanation:
        "Cristiano Ronaldo holds the record with over 130 international goals.",
    },
    {
      id: 7,
      question: "Which World Cup saw the introduction of VAR?",
      options: [
        "Brazil 2014",
        "Russia 2018",
        "Qatar 2022",
        "South Africa 2010",
      ],
      correctAnswer: 1,
      explanation: "VAR was first used in the 2018 World Cup in Russia.",
    },
    {
      id: 8,
      question: "What is the maximum transfer fee ever paid for a player?",
      options: ["€200 million", "€222 million", "€300 million", "€400 million"],
      correctAnswer: 1,
      explanation:
        "Neymar's transfer to PSG for €222 million remains the record.",
    },
    {
      id: 9,
      question: "Which league is known as 'La Liga'?",
      options: [
        "Italian Serie A",
        "German Bundesliga",
        "Spanish Primera División",
        "French Ligue 1",
      ],
      correctAnswer: 2,
      explanation:
        "La Liga is the top professional football division in Spain.",
    },
    {
      id: 10,
      question: "Who was the first African player to win the Ballon d'Or?",
      options: ["Samuel Eto'o", "George Weah", "Didier Drogba", "Yaya Touré"],
      correctAnswer: 1,
      explanation: "George Weah won the Ballon d'Or in 1995.",
    },
  ],
  4: [
    // Level 4: Expert - Advanced football history
    {
      id: 1,
      question:
        "Which team completed the 'Invincibles' season in the Premier League?",
      options: ["Manchester United", "Chelsea", "Arsenal", "Liverpool"],
      correctAnswer: 2,
      explanation:
        "Arsenal went unbeaten throughout the 2003-04 Premier League season.",
    },
    {
      id: 2,
      question: "Who scored the fastest hat-trick in Premier League history?",
      options: ["Alan Shearer", "Sadio Mané", "Robbie Fowler", "Sergio Agüero"],
      correctAnswer: 1,
      explanation:
        "Sadio Mané scored a hat-trick in 2 minutes 56 seconds in 2015.",
    },
    {
      id: 3,
      question:
        "Which goalkeeper has the most clean sheets in Premier League history?",
      options: [
        "Peter Schmeichel",
        "Petr Čech",
        "David Seaman",
        "Edwin van der Sar",
      ],
      correctAnswer: 1,
      explanation:
        "Petr Čech holds the record with 202 Premier League clean sheets.",
    },
    {
      id: 4,
      question:
        "What was the score in Brazil's infamous World Cup semi-final loss to Germany in 2014?",
      options: ["1-5", "1-7", "0-6", "2-8"],
      correctAnswer: 1,
      explanation:
        "Germany defeated Brazil 7-1 in the 2014 World Cup semi-final.",
    },
    {
      id: 5,
      question:
        "Which player holds the record for most assists in a single Premier League season?",
      options: [
        "Kevin De Bruyne",
        "Thierry Henry",
        "Frank Lampard",
        "Cesc Fàbregas",
      ],
      correctAnswer: 0,
      explanation: "Kevin De Bruyne set the record with 20 assists in 2019-20.",
    },
    {
      id: 6,
      question:
        "Who was the first player to score in five different World Cups?",
      options: ["Pelé", "Miroslav Klose", "Cristiano Ronaldo", "Thierry Henry"],
      correctAnswer: 2,
      explanation:
        "Cristiano Ronaldo scored in five consecutive World Cups (2006-2022).",
    },
    {
      id: 7,
      question: "Which club has won the most FA Cup titles?",
      options: ["Manchester United", "Liverpool", "Arsenal", "Chelsea"],
      correctAnswer: 2,
      explanation: "Arsenal has won the FA Cup 14 times, the most of any club.",
    },
    {
      id: 8,
      question: "What is the record for most goals scored in a calendar year?",
      options: ["85 goals", "91 goals", "95 goals", "89 goals"],
      correctAnswer: 1,
      explanation: "Lionel Messi scored 91 goals in the calendar year 2012.",
    },
    {
      id: 9,
      question: "Which country hosted the first-ever FIFA World Cup?",
      options: ["Brazil", "England", "Uruguay", "Italy"],
      correctAnswer: 2,
      explanation: "Uruguay hosted and won the first World Cup in 1930.",
    },
    {
      id: 10,
      question: "Who is the youngest player to score in a World Cup final?",
      options: ["Pelé", "Kylian Mbappé", "Michael Owen", "Ronaldo"],
      correctAnswer: 0,
      explanation: "Pelé was 17 when he scored in the 1958 World Cup final.",
    },
  ],
  5: [
    // Level 5: Legend - Master of football knowledge
    {
      id: 1,
      question: "Which player has played in the most World Cup tournaments?",
      options: [
        "Lothar Matthäus",
        "Gianluigi Buffon",
        "Alfredo Talavera",
        "Rafael Márquez",
      ],
      correctAnswer: 2,
      explanation: "Alfredo Talavera appeared in 5 World Cups (2006-2022).",
    },
    {
      id: 2,
      question:
        "What is the official name of the trophy awarded to the World Cup winners?",
      options: [
        "FIFA World Cup",
        "Jules Rimet Trophy",
        "FIFA World Cup Trophy",
        "Golden Globe",
      ],
      correctAnswer: 2,
      explanation:
        "The current trophy is officially called the FIFA World Cup Trophy.",
    },
    {
      id: 3,
      question: "Which club has the longest unbeaten run in football history?",
      options: ["AC Milan", "Steaua Bucharest", "Juventus", "Barcelona"],
      correctAnswer: 1,
      explanation: "Steaua Bucharest went 104 matches unbeaten from 1986-1989.",
    },
    {
      id: 4,
      question: "Who scored the fastest goal in World Cup history?",
      options: ["Hakan Şükür", "Alan Shearer", "Clint Dempsey", "Tim Cahill"],
      correctAnswer: 0,
      explanation: "Hakan Şükür scored after 11 seconds for Turkey in 2002.",
    },
    {
      id: 5,
      question:
        "Which formation is credited with revolutionizing modern football tactics?",
      options: ["4-4-2", "4-3-3", "3-5-2", "Total Football"],
      correctAnswer: 3,
      explanation:
        "Total Football, pioneered by Ajax and Netherlands, revolutionized tactics.",
    },
    {
      id: 6,
      question:
        "Who is the only player to win Champions League with three different clubs?",
      options: ["Kaká", "Clarence Seedorf", "Andrea Pirlo", "Xabi Alonso"],
      correctAnswer: 1,
      explanation:
        "Seedorf won with Ajax, Real Madrid, AC Milan, and was part of multiple teams.",
    },
    {
      id: 7,
      question:
        "What is the highest attendance ever recorded for a football match?",
      options: ["199,854", "200,000", "173,850", "210,000"],
      correctAnswer: 0,
      explanation:
        "199,854 attended the 1950 World Cup final at Maracanã Stadium.",
    },
    {
      id: 8,
      question:
        "Which goalkeeper has scored the most goals in professional football?",
      options: [
        "José Luis Chilavert",
        "Rogério Ceni",
        "Jorge Campos",
        "René Higuita",
      ],
      correctAnswer: 1,
      explanation:
        "Rogério Ceni scored 131 goals in his career, a record for goalkeepers.",
    },
    {
      id: 9,
      question: "Who was the first $100 million transfer in football history?",
      options: ["Kaká", "Gareth Bale", "Cristiano Ronaldo", "Luis Figo"],
      correctAnswer: 0,
      explanation:
        "Kaká's transfer to Real Madrid in 2009 was the first to exceed $100 million.",
    },
    {
      id: 10,
      question:
        "Which country has appeared in the most World Cup finals without winning?",
      options: ["Netherlands", "Czechoslovakia", "Hungary", "Sweden"],
      correctAnswer: 0,
      explanation:
        "Netherlands has reached 3 World Cup finals (1974, 1978, 2010) without winning.",
    },
  ],
};

export default function Quiz() {
  const navigate = useNavigate();
  const { levelId } = useParams<{ levelId: string }>();
  const currentLevel = parseInt(levelId || "1", 10);

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [coins, setCoins] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const [questions, setQuestions] = useState(
    questionsByLevel[currentLevel] || questionsByLevel[1],
  );
  const [timeLeft, setTimeLeft] = useState(30);
  const [gameFinished, setGameFinished] = useState(false);

  // Power-up states
  const [inventory, setInventory] = useState<{ [key: string]: number }>({});
  const [usedSecondChance, setUsedSecondChance] = useState(false);
  const [timeBoostActive, setTimeBoostActive] = useState(false);
  const [doubleCoinBonus, setDoubleCoinBonus] = useState(0);

  const levelNames = {
    1: "Rookie",
    2: "Amateur",
    3: "Professional",
    4: "Expert",
    5: "Legend",
  };

  // Reset quiz state when level changes
  useEffect(() => {
    const newQuestions = questionsByLevel[currentLevel] || questionsByLevel[1];
    setQuestions(newQuestions);
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setScore(0);
    setShowResult(false);
    setShowExplanation(false);
    setTimeLeft(30);
    setGameFinished(false);
    setUsedSecondChance(false);
    setTimeBoostActive(false);
    setCurrentCoinReward(10);
  }, [currentLevel]);

  // Load coins and inventory from localStorage
  useEffect(() => {
    const savedCoins = localStorage.getItem("footballQuizCoins");
    if (savedCoins) {
      setCoins(parseInt(savedCoins, 10));
    }

    const savedInventory = localStorage.getItem("footballRoutineInventory");
    if (savedInventory) {
      setInventory(JSON.parse(savedInventory));
    }

    const savedDoubleCoinBonus = localStorage.getItem(
      "footballRoutineDoubleCoinBonus",
    );
    if (savedDoubleCoinBonus) {
      setDoubleCoinBonus(parseInt(savedDoubleCoinBonus, 10));
    }
  }, []);

  // Power-up functions
  const useTimeBoost = () => {
    if (inventory.timeBoost > 0 && !timeBoostActive) {
      setTimeBoostActive(true);
      setTimeLeft((prev) => prev + 15);
      const newInventory = { ...inventory, timeBoost: inventory.timeBoost - 1 };
      setInventory(newInventory);
      localStorage.setItem(
        "footballRoutineInventory",
        JSON.stringify(newInventory),
      );
    }
  };

  const useSecondChance = () => {
    if (
      inventory.secondChance > 0 &&
      !usedSecondChance &&
      showResult &&
      !isCorrect
    ) {
      setUsedSecondChance(true);
      setShowResult(false);
      setShowExplanation(false);
      setSelectedAnswer(null);
      const newInventory = {
        ...inventory,
        secondChance: inventory.secondChance - 1,
      };
      setInventory(newInventory);
      localStorage.setItem(
        "footballRoutineInventory",
        JSON.stringify(newInventory),
      );
    }
  };

  const useDoubleCoin = () => {
    if (inventory.doubleCoins > 0 && doubleCoinBonus === 0) {
      setDoubleCoinBonus(3); // 3 correct answers with double coins
      localStorage.setItem("footballRoutineDoubleCoinBonus", "3");
      const newInventory = {
        ...inventory,
        doubleCoins: inventory.doubleCoins - 1,
      };
      setInventory(newInventory);
      localStorage.setItem(
        "footballRoutineInventory",
        JSON.stringify(newInventory),
      );
    }
  };

  // Timer effect
  useEffect(() => {
    if (timeLeft > 0 && !showResult && !gameFinished) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showResult) {
      handleTimeUp();
    }
  }, [timeLeft, showResult, gameFinished]);

  const handleTimeUp = () => {
    setSelectedAnswer(null);
    setShowResult(true);
    setShowExplanation(true);
  };

  const [currentCoinReward, setCurrentCoinReward] = useState(10);

  const handleAnswerSelect = (answerIndex: number) => {
    if (showResult) return;
    setSelectedAnswer(answerIndex);
    setShowResult(true);
    setShowExplanation(true);

    const isCorrect = answerIndex === questions[currentQuestion].correctAnswer;
    if (isCorrect) {
      const newScore = score + 1;
      const coinReward = doubleCoinBonus > 0 ? 20 : 10; // Double coins if bonus active
      setCurrentCoinReward(coinReward); // Store for message display
      const newCoins = coins + coinReward;
      setScore(newScore);
      setCoins(newCoins);
      localStorage.setItem("footballQuizCoins", newCoins.toString());

      // Track achievements
      addCoinsToTotal(coinReward);
      updateStreak(true);

      // Reduce double coin bonus counter after each correct answer
      if (doubleCoinBonus > 0) {
        const newBonus = doubleCoinBonus - 1;
        setDoubleCoinBonus(newBonus);
        localStorage.setItem(
          "footballRoutineDoubleCoinBonus",
          newBonus.toString(),
        );
      }
    } else {
      setCurrentCoinReward(0); // No coins for wrong answer
      // Track failed streak
      updateStreak(false);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion + 1 < questions.length) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setShowExplanation(false);
      setTimeLeft(30);
      setCurrentCoinReward(10); // Reset coin reward display
    } else {
      setGameFinished(true);

      // Track routine completion
      completeRoutine(score, questions.length);

      // Unlock next level if player scored well
      if (score >= 7) {
        // 70% or better unlocks next level
        const unlockedLevels = localStorage.getItem(
          "footballRoutineUnlockedLevels",
        );
        const currentUnlocked = unlockedLevels
          ? parseInt(unlockedLevels, 10)
          : 1;
        if (currentLevel >= currentUnlocked && currentLevel < 5) {
          const nextLevel = currentLevel + 1;
          localStorage.setItem(
            "footballRoutineUnlockedLevels",
            nextLevel.toString(),
          );
          // Track level unlocking for achievements
          updateUnlockedLevels(nextLevel);
        }
      }
    }
  };

  const restartQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setScore(0);
    setShowResult(false);
    setShowExplanation(false);
    setTimeLeft(30);
    setGameFinished(false);
    setUsedSecondChance(false);
    setTimeBoostActive(false);
    setCurrentCoinReward(10);
  };

  const currentQ = questions[currentQuestion];
  const isCorrect = selectedAnswer === currentQ.correctAnswer;

  if (gameFinished) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-dark via-dark-lighter to-dark-darker flex items-center justify-center p-6">
        <div className="max-w-md w-full">
          <div className="bg-card-glass rounded-2xl p-8 border border-border/50 shadow-card-soft text-center">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-3xl font-display font-bold text-gold mb-2">
              Level {currentLevel} Complete!
            </h2>
            <p className="text-electric font-medium mb-4">
              {levelNames[currentLevel as keyof typeof levelNames]} Routine
              Finished
            </p>
            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-center p-3 bg-dark-lighter rounded-lg">
                <span className="text-dark-foreground">Score:</span>
                <span className="text-gold font-bold">
                  {score}/{questions.length}
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-dark-lighter rounded-lg">
                <span className="text-dark-foreground">Accuracy:</span>
                <span className="text-electric font-bold">
                  {Math.round((score / questions.length) * 100)}%
                </span>
              </div>
              <div className="flex justify-between items-center p-3 bg-dark-lighter rounded-lg">
                <span className="text-dark-foreground">Coins Earned:</span>
                <span className="text-gold font-bold coin-glow">
                  +{score * (doubleCoinBonus > 0 ? 20 : 10)} 🪙
                  {doubleCoinBonus > 0 && (
                    <span className="text-sm ml-1">(2x Bonus!)</span>
                  )}
                </span>
              </div>
            </div>

            {score >= 7 && currentLevel < 5 && (
              <div className="mb-6 p-4 bg-electric/20 border border-electric rounded-xl">
                <div className="text-2xl mb-2">🔓</div>
                <div className="text-electric font-bold">
                  Next Level Unlocked!
                </div>
                <div className="text-electric/80 text-sm">
                  You scored 70% or better
                </div>
              </div>
            )}

            <div className="space-y-3">
              {score >= 7 && currentLevel < 5 && (
                <button
                  onClick={() => navigate(`/quiz/${currentLevel + 1}`)}
                  className="w-full bg-gradient-to-r from-electric to-gold text-dark font-bold py-3 px-6 rounded-xl hover:scale-105 transition-transform shadow-glow-electric"
                >
                  Next Level (
                  {levelNames[(currentLevel + 1) as keyof typeof levelNames]})
                </button>
              )}
              <button
                onClick={restartQuiz}
                className="w-full bg-gradient-to-r from-gold to-electric text-dark font-bold py-3 px-6 rounded-xl hover:scale-105 transition-transform shadow-glow"
              >
                Play Again
              </button>
              <button
                onClick={() => navigate("/levels")}
                className="w-full bg-card border border-border text-dark-foreground font-medium py-3 px-6 rounded-xl hover:scale-105 transition-transform"
              >
                Level Selection
              </button>
              <button
                onClick={() => navigate("/")}
                className="w-full bg-card border border-border text-dark-foreground font-medium py-3 px-6 rounded-xl hover:scale-105 transition-transform"
              >
                Back to Home
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-lighter to-dark-darker">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,215,0,0.1),transparent_50%)]" />

      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-gold hover:text-gold-light transition-colors"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          Back
        </button>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-card-glass rounded-xl px-3 py-2 border border-electric/20">
            <span className="text-electric font-bold">
              Level {currentLevel}
            </span>
            <span className="text-electric/70">
              - {levelNames[currentLevel as keyof typeof levelNames]}
            </span>
          </div>
          <div className="flex items-center gap-2 bg-card-glass rounded-xl px-4 py-2 border border-gold/20">
            <span className="text-gold font-bold">{currentQuestion + 1}</span>
            <span className="text-gold/70">/ {questions.length}</span>
          </div>
          <div className="flex items-center gap-2 bg-card-glass rounded-xl px-4 py-2 border border-border/50">
            <span className="text-2xl coin-glow">🪙</span>
            <span className="text-gold font-bold">{coins}</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 pb-8">
        <div className="max-w-2xl mx-auto">
          {/* Timer */}
          <div className="mb-6">
            <div className="flex items-center justify-center gap-2 mb-2">
              <span className="text-2xl">⏱️</span>
              <span className="text-xl font-bold text-electric">
                {timeLeft}s
              </span>
            </div>
            <div className="w-full bg-dark-lighter rounded-full h-2">
              <div
                className="bg-gradient-to-r from-electric to-gold h-2 rounded-full transition-all duration-1000"
                style={{ width: `${(timeLeft / 30) * 100}%` }}
              />
            </div>
          </div>

          {/* Power-ups Panel */}
          {(inventory.timeBoost > 0 ||
            inventory.secondChance > 0 ||
            inventory.doubleCoins > 0) && (
            <div className="mb-6 p-4 bg-card-glass rounded-xl border border-border/50 shadow-card-soft">
              <h3 className="text-sm font-bold text-gold mb-3 text-center">
                Power-ups Available
              </h3>
              <div className="flex gap-2 justify-center">
                {inventory.timeBoost > 0 && !timeBoostActive && (
                  <button
                    onClick={useTimeBoost}
                    className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-electric to-gold text-dark text-sm font-bold rounded-lg hover:scale-105 transition-transform"
                  >
                    <span>⏰</span>
                    <span>+15s ({inventory.timeBoost})</span>
                  </button>
                )}

                {inventory.secondChance > 0 &&
                  !usedSecondChance &&
                  showResult &&
                  !isCorrect && (
                    <button
                      onClick={useSecondChance}
                      className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-gold to-electric text-dark text-sm font-bold rounded-lg hover:scale-105 transition-transform"
                    >
                      <span>🔄</span>
                      <span>Retry ({inventory.secondChance})</span>
                    </button>
                  )}

                {inventory.doubleCoins > 0 && doubleCoinBonus === 0 && (
                  <button
                    onClick={useDoubleCoin}
                    className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-gold-dark to-gold-light text-dark text-sm font-bold rounded-lg hover:scale-105 transition-transform"
                  >
                    <span>💰</span>
                    <span>2x Coins ({inventory.doubleCoins})</span>
                  </button>
                )}
              </div>

              {doubleCoinBonus > 0 && (
                <div className="mt-3 text-center">
                  <span className="text-sm text-gold font-medium">
                    💰 Double Coins Active ({doubleCoinBonus} correct answers
                    left)
                  </span>
                  <div className="text-xs text-gold/70 mt-1">
                    Getting 20 coins per correct answer instead of 10
                  </div>
                </div>
              )}

              {timeBoostActive && (
                <div className="mt-3 text-center">
                  <span className="text-sm text-electric font-medium">
                    ⏰ Time Boost Used (+15 seconds)
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Question Card */}
          <div className="bg-card-glass rounded-2xl p-8 border border-border/50 shadow-card-soft mb-6">
            <h2 className="text-2xl font-display font-bold text-gold mb-6 text-center">
              {currentQ.question}
            </h2>

            {/* Answer Options */}
            <div className="space-y-4">
              {currentQ.options.map((option, index) => {
                let buttonClass =
                  "w-full p-4 rounded-xl border-2 text-left transition-all duration-300 font-medium";

                if (showResult) {
                  if (index === currentQ.correctAnswer) {
                    buttonClass +=
                      " bg-green-500/20 border-green-500 text-green-400";
                  } else if (
                    index === selectedAnswer &&
                    index !== currentQ.correctAnswer
                  ) {
                    buttonClass += " bg-red-500/20 border-red-500 text-red-400";
                  } else {
                    buttonClass +=
                      " bg-card border-border/50 text-dark-foreground/50";
                  }
                } else {
                  buttonClass +=
                    " bg-card border-border/50 text-dark-foreground hover:border-gold hover:bg-gold/10 hover:scale-105";
                }

                return (
                  <button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    disabled={showResult}
                    className={buttonClass}
                  >
                    <span className="font-bold text-gold mr-3">
                      {String.fromCharCode(65 + index)}.
                    </span>
                    {option}
                  </button>
                );
              })}
            </div>

            {/* Result Message */}
            {showResult && (
              <div
                className={`mt-6 p-4 rounded-xl text-center ${isCorrect ? "bg-green-500/20 border border-green-500" : "bg-red-500/20 border border-red-500"}`}
              >
                <div className="text-2xl mb-2">{isCorrect ? "✅" : "❌"}</div>
                <div className="font-bold text-lg mb-2">
                  {isCorrect
                    ? `Correct! +${currentCoinReward} Coins${currentCoinReward === 20 ? " (Double Bonus!)" : ""}`
                    : "Wrong! No coins"}
                </div>
                {showExplanation && (
                  <div className="text-sm text-dark-foreground/80">
                    {currentQ.explanation}
                  </div>
                )}
              </div>
            )}

            {/* Next Button */}
            {showResult && (
              <div className="mt-6 text-center">
                <button
                  onClick={handleNextQuestion}
                  className="bg-gradient-to-r from-gold to-electric text-dark font-bold py-3 px-8 rounded-xl hover:scale-105 transition-transform shadow-glow"
                >
                  {currentQuestion + 1 < questions.length
                    ? "Next Question"
                    : "Finish Quiz"}
                </button>
              </div>
            )}
          </div>

          {/* Progress Bar */}
          <div className="bg-dark-lighter rounded-full h-2">
            <div
              className="bg-gradient-to-r from-gold to-electric h-2 rounded-full transition-all duration-500"
              style={{
                width: `${((currentQuestion + (showResult ? 1 : 0)) / questions.length) * 100}%`,
              }}
            />
          </div>
        </div>
      </main>

      {/* Copyright Footer */}
      <footer className="relative z-10 p-6 text-center border-t border-border/20">
        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-4 text-sm">
            <button
              onClick={() => navigate("/privacy")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Privacy Policy
            </button>
            <span className="text-dark-foreground/40">•</span>
            <button
              onClick={() => navigate("/terms")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Terms of Service
            </button>
          </div>
          <p className="text-dark-foreground/60 text-sm">
            © Copyright owned by abatynawy
          </p>
        </div>
      </footer>
    </div>
  );
}
