import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { PlayerStats, getPlayerStats } from "@shared/achievements";

export default function Coins() {
  const navigate = useNavigate();
  const [coins, setCoins] = useState(0);
  const [playerStats, setPlayerStats] = useState<PlayerStats>(getPlayerStats());
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>(
    [],
  );

  useEffect(() => {
    const savedCoins = localStorage.getItem("footballQuizCoins");
    if (savedCoins) {
      setCoins(parseInt(savedCoins, 10));
    }

    // Load player stats
    setPlayerStats(getPlayerStats());

    // Load unlocked achievements
    const savedAchievements = localStorage.getItem(
      "footballRoutineAchievements",
    );
    if (savedAchievements) {
      setUnlockedAchievements(JSON.parse(savedAchievements));
    }
  }, []);

  const achievements = [
    {
      id: "firstRoutine",
      title: "First Routine",
      description: "Complete your first routine",
      coins: 50,
      icon: "🎯",
      unlocked: unlockedAchievements.includes("firstRoutine"),
      condition: () => playerStats.routinesCompleted >= 1,
    },
    {
      id: "perfectScore",
      title: "Routine Master",
      description: "Score 100% on a routine",
      coins: 100,
      icon: "🏆",
      unlocked: unlockedAchievements.includes("perfectScore"),
      condition: () => playerStats.perfectScores >= 1,
    },
    {
      id: "coinCollector",
      title: "Coin Collector",
      description: "Earn 500 total coins",
      coins: 200,
      icon: "💎",
      unlocked: unlockedAchievements.includes("coinCollector"),
      condition: () => playerStats.totalCoinsEarned >= 500,
    },
    {
      id: "streakLegend",
      title: "Streak Legend",
      description: "Get 10 questions right in a row",
      coins: 300,
      icon: "🔥",
      unlocked: unlockedAchievements.includes("streakLegend"),
      condition: () => playerStats.maxStreak >= 10,
    },
    {
      id: "levelExplorer",
      title: "Level Explorer",
      description: "Unlock all 5 levels",
      coins: 500,
      icon: "🗺️",
      unlocked: unlockedAchievements.includes("levelExplorer"),
      condition: () => playerStats.levelsUnlocked >= 5,
    },
    {
      id: "coinMaster",
      title: "Coin Master",
      description: "Earn 1000 total coins",
      coins: 750,
      icon: "👑",
      unlocked: unlockedAchievements.includes("coinMaster"),
      condition: () => playerStats.totalCoinsEarned >= 1000,
    },
  ];

  // Check for newly unlocked achievements
  const checkAchievements = () => {
    let newAchievements: string[] = [];
    let bonusCoins = 0;

    achievements.forEach((achievement) => {
      if (!achievement.unlocked && achievement.condition()) {
        newAchievements.push(achievement.id);
        bonusCoins += achievement.coins;
      }
    });

    if (newAchievements.length > 0) {
      const updatedAchievements = [...unlockedAchievements, ...newAchievements];
      setUnlockedAchievements(updatedAchievements);
      localStorage.setItem(
        "footballRoutineAchievements",
        JSON.stringify(updatedAchievements),
      );

      // Award bonus coins
      const newCoins = coins + bonusCoins;
      setCoins(newCoins);
      localStorage.setItem("footballQuizCoins", newCoins.toString());

      // Show achievement notification only for new unlocks
      newAchievements.forEach((id) => {
        const achievement = achievements.find((a) => a.id === id);
        if (achievement) {
          alert(
            `🏆 Achievement Unlocked!\n${achievement.title}\n+${achievement.coins} coins!`,
          );
        }
      });
    }
  };

  // Only check achievements when stats actually change, not on page load
  const [hasCheckedInitialAchievements, setHasCheckedInitialAchievements] =
    useState(false);

  useEffect(() => {
    if (hasCheckedInitialAchievements) {
      checkAchievements();
    } else {
      setHasCheckedInitialAchievements(true);
    }
  }, [playerStats]);

  const coinPacks = [
    {
      name: "Time Boost",
      price: 50,
      description: "Get +15 seconds for each question",
      icon: "⏰",
      id: "timeBoost",
    },
    {
      name: "Second Chance",
      description: "Retry wrong answers once",
      price: 75,
      icon: "🔄",
      id: "secondChance",
    },
    {
      name: "Double Coins",
      description: "Earn 2x coins for next 3 correct answers",
      price: 100,
      icon: "💰",
      id: "doubleCoins",
    },
  ];

  const handlePurchase = (item: (typeof coinPacks)[0]) => {
    if (coins >= item.price) {
      const newCoins = coins - item.price;
      setCoins(newCoins);
      localStorage.setItem("footballQuizCoins", newCoins.toString());

      // Add purchased item to inventory
      const inventory = JSON.parse(
        localStorage.getItem("footballRoutineInventory") || "{}",
      );
      inventory[item.id] = (inventory[item.id] || 0) + 1;
      localStorage.setItem(
        "footballRoutineInventory",
        JSON.stringify(inventory),
      );

      // Show success message (you could add a toast notification here)
      alert(`✅ ${item.name} purchased successfully!`);
    }
  };

  // Get current inventory
  const inventory = JSON.parse(
    localStorage.getItem("footballRoutineInventory") || "{}",
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-lighter to-dark-darker">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,215,0,0.2),transparent_50%)]" />

      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-gold hover:text-gold-light transition-colors"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          Back
        </button>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-gold to-electric rounded-xl flex items-center justify-center text-xl coin-glow">
            🪙
          </div>
          <h1 className="text-xl font-display font-bold text-gold">My Coins</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 pb-8">
        <div className="max-w-4xl mx-auto">
          {/* Coin Balance */}
          <div className="text-center mb-8">
            <div className="bg-card-glass rounded-2xl p-8 border border-gold/20 shadow-glow inline-block">
              <div className="text-6xl mb-4 coin-glow">🪙</div>
              <div className="text-4xl font-display font-bold text-gold mb-2">
                {coins}
              </div>
              <div className="text-gold/70">Total Coins</div>
            </div>
          </div>

          {/* Achievements */}
          <section className="mb-8">
            <h2 className="text-2xl font-display font-bold text-gold mb-6 text-center">
              🏆 Achievements
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {achievements.map((achievement, index) => {
                let progressText = "";
                let progressPercent = 0;

                // Calculate progress for each achievement
                if (achievement.id === "firstRoutine") {
                  progressText = `${playerStats.routinesCompleted}/1 routines`;
                  progressPercent =
                    Math.min(playerStats.routinesCompleted / 1, 1) * 100;
                } else if (achievement.id === "perfectScore") {
                  progressText = `${playerStats.perfectScores}/1 perfect scores`;
                  progressPercent =
                    Math.min(playerStats.perfectScores / 1, 1) * 100;
                } else if (achievement.id === "coinCollector") {
                  progressText = `${playerStats.totalCoinsEarned}/500 coins earned`;
                  progressPercent =
                    Math.min(playerStats.totalCoinsEarned / 500, 1) * 100;
                } else if (achievement.id === "streakLegend") {
                  progressText = `${playerStats.maxStreak}/10 max streak`;
                  progressPercent =
                    Math.min(playerStats.maxStreak / 10, 1) * 100;
                } else if (achievement.id === "levelExplorer") {
                  progressText = `${playerStats.levelsUnlocked}/5 levels unlocked`;
                  progressPercent =
                    Math.min(playerStats.levelsUnlocked / 5, 1) * 100;
                } else if (achievement.id === "coinMaster") {
                  progressText = `${playerStats.totalCoinsEarned}/1000 coins earned`;
                  progressPercent =
                    Math.min(playerStats.totalCoinsEarned / 1000, 1) * 100;
                }

                return (
                  <div
                    key={index}
                    className={`p-6 rounded-xl border transition-all duration-300 ${
                      achievement.unlocked
                        ? "bg-card-glass border-gold/50 shadow-glow"
                        : "bg-card border-border/30"
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-3xl">{achievement.icon}</span>
                      <div className="flex-1">
                        <h3 className="font-bold text-gold">
                          {achievement.title}
                        </h3>
                        <p className="text-sm text-dark-foreground/70">
                          {achievement.description}
                        </p>
                        {!achievement.unlocked && (
                          <div className="mt-2">
                            <div className="text-xs text-dark-foreground/60 mb-1">
                              {progressText}
                            </div>
                            <div className="w-full bg-dark-lighter rounded-full h-2">
                              <div
                                className="bg-gradient-to-r from-gold to-electric h-2 rounded-full transition-all duration-500"
                                style={{ width: `${progressPercent}%` }}
                              />
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="text-gold font-bold">
                          +{achievement.coins}
                        </div>
                        <div className="text-xs text-gold/70">coins</div>
                      </div>
                    </div>
                    {achievement.unlocked && (
                      <div className="mt-3 text-center">
                        <span className="inline-flex items-center gap-1 text-green-400 text-sm font-medium">
                          ✅ Unlocked & Claimed
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {/* Coin Store */}
          <section>
            <h2 className="text-2xl font-display font-bold text-gold mb-6 text-center">
              🛒 Coin Store
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {coinPacks.map((pack, index) => (
                <div
                  key={index}
                  className="bg-card-glass p-6 rounded-xl border border-border/50 shadow-card-soft hover:scale-105 transition-transform"
                >
                  <div className="text-center mb-4">
                    <span className="text-4xl mb-2 block">{pack.icon}</span>
                    <h3 className="font-bold text-gold text-lg">{pack.name}</h3>
                    <p className="text-sm text-dark-foreground/70 mb-4">
                      {pack.description}
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-electric mb-2">
                      {pack.price} 🪙
                    </div>
                    {inventory[pack.id] > 0 && (
                      <div className="text-sm text-gold mb-2">
                        Owned: {inventory[pack.id]}
                      </div>
                    )}
                    <button
                      disabled={coins < pack.price}
                      onClick={() => handlePurchase(pack)}
                      className={`w-full py-2 px-4 rounded-lg font-medium transition-all ${
                        coins >= pack.price
                          ? "bg-gradient-to-r from-gold to-electric text-dark hover:scale-105 shadow-glow"
                          : "bg-muted text-muted-foreground cursor-not-allowed"
                      }`}
                    >
                      {coins >= pack.price ? "Purchase" : "Not enough coins"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Earn More Coins */}
          <div className="mt-8 text-center">
            <div className="bg-card-glass rounded-xl p-6 border border-electric/20 shadow-glow-electric">
              <h3 className="text-xl font-bold text-electric mb-3">
                Want more coins?
              </h3>
              <p className="text-dark-foreground/80 mb-4">
                Take more routines to earn coins and unlock achievements!
              </p>
              <button
                onClick={() => navigate("/levels")}
                className="bg-gradient-to-r from-electric to-gold text-dark font-bold py-3 px-6 rounded-xl hover:scale-105 transition-transform shadow-glow"
              >
                Start New Routine
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Copyright Footer */}
      <footer className="relative z-10 p-6 text-center border-t border-border/20">
        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-4 text-sm">
            <button
              onClick={() => navigate("/privacy")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Privacy Policy
            </button>
            <span className="text-dark-foreground/40">•</span>
            <button
              onClick={() => navigate("/terms")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Terms of Service
            </button>
          </div>
          <p className="text-dark-foreground/60 text-sm">
            © Copyright owned by abatynawy
          </p>
        </div>
      </footer>
    </div>
  );
}
