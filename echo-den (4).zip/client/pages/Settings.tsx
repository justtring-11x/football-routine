import { useNavigate } from "react-router-dom";

export default function Settings() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-lighter to-dark-darker">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(0,123,255,0.1),transparent_50%)]" />

      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-gold hover:text-gold-light transition-colors"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          Back
        </button>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-electric to-gold rounded-xl flex items-center justify-center text-xl">
            ⚙️
          </div>
          <h1 className="text-xl font-display font-bold text-gold">Settings</h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 pb-8">
        <div className="max-w-2xl mx-auto">
          <div className="bg-card-glass rounded-2xl p-8 border border-border/50 shadow-card-soft">
            <div className="text-center mb-8">
              <div className="text-6xl mb-4">⚙️</div>
              <h2 className="text-3xl font-display font-bold text-gold mb-4">
                Settings
              </h2>
              <p className="text-dark-foreground/80">
                Customize your football routine experience
              </p>
            </div>

            <div className="space-y-6">
              {/* Sound Settings */}
              <div className="p-4 bg-dark-lighter rounded-xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">🔊</span>
                    <div>
                      <h3 className="font-bold text-gold">Sound Effects</h3>
                      <p className="text-sm text-dark-foreground/70">
                        Enable sound for correct/wrong answers
                      </p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" />
                    <div className="w-11 h-6 bg-dark rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-electric"></div>
                  </label>
                </div>
              </div>

              {/* Timer */}
              <div className="p-4 bg-dark-lighter rounded-xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">⏱️</span>
                    <div>
                      <h3 className="font-bold text-gold">Timer</h3>
                      <p className="text-sm text-dark-foreground/70">
                        Enable timer for each question
                      </p>
                    </div>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      className="sr-only peer"
                      defaultChecked
                    />
                    <div className="w-11 h-6 bg-dark rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-electric"></div>
                  </label>
                </div>
              </div>

              {/* Data */}
              <div className="p-4 bg-dark-lighter rounded-xl">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-2xl">💾</span>
                  <div>
                    <h3 className="font-bold text-gold">Game Data</h3>
                    <p className="text-sm text-dark-foreground/70">
                      Manage your saved progress
                    </p>
                  </div>
                </div>
                <button className="w-full py-2 px-4 bg-destructive text-destructive-foreground rounded-lg font-medium hover:bg-destructive/80 transition-colors">
                  Reset All Progress
                </button>
              </div>

              {/* About */}
              <div className="p-4 bg-dark-lighter rounded-xl">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">ℹ️</span>
                  <div>
                    <h3 className="font-bold text-gold">About</h3>
                    <p className="text-sm text-dark-foreground/70">
                      Football Routine App v1.0.0
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 text-center">
              <p className="text-dark-foreground/60 text-sm">
                More customization options coming soon! 🚀
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Copyright Footer */}
      <footer className="relative z-10 p-6 text-center border-t border-border/20">
        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-4 text-sm">
            <button
              onClick={() => navigate("/privacy")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Privacy Policy
            </button>
            <span className="text-dark-foreground/40">•</span>
            <button
              onClick={() => navigate("/terms")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Terms of Service
            </button>
          </div>
          <p className="text-dark-foreground/60 text-sm">
            © Copyright owned by abatynawy
          </p>
        </div>
      </footer>
    </div>
  );
}
