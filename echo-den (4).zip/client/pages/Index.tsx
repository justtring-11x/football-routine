import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Index() {
  const navigate = useNavigate();
  const [coins, setCoins] = useState(0);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallButton, setShowInstallButton] = useState(false);

  // Load coins from localStorage on mount
  useEffect(() => {
    const savedCoins = localStorage.getItem("footballQuizCoins");
    if (savedCoins) {
      setCoins(parseInt(savedCoins, 10));
    }

    // PWA Install prompt handling
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstallButton(true);
    };

    const handleAppInstalled = () => {
      setShowInstallButton(false);
      setDeferredPrompt(null);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);

    // Check if app is already installed
    if (window.matchMedia("(display-mode: standalone)").matches) {
      setShowInstallButton(false);
    }

    return () => {
      window.removeEventListener(
        "beforeinstallprompt",
        handleBeforeInstallPrompt,
      );
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setShowInstallButton(false);
      }
      setDeferredPrompt(null);
    }
  };

  const menuItems = [
    {
      title: "Start Routine",
      description: "Begin your football training",
      icon: "🧠",
      gradient: "from-gold via-gold-light to-electric",
      onClick: () => navigate("/levels"),
      glow: "shadow-glow",
    },
    {
      title: "Guess the Player",
      description: "Identify players from their career",
      icon: "⚽",
      gradient: "from-electric via-electric-light to-gold",
      onClick: () => navigate("/guess-player"),
      glow: "shadow-glow-electric",
    },
    {
      title: "My Coins",
      description: `You have ${coins} coins`,
      icon: "🪙",
      gradient: "from-gold-dark via-gold to-gold-light",
      onClick: () => navigate("/coins"),
      glow: "shadow-glow",
    },
    {
      title: "Settings",
      description: "Customize your experience",
      icon: "⚙️",
      gradient: "from-dark-lighter via-muted to-dark-lighter",
      onClick: () => navigate("/settings"),
      glow: "shadow-card-soft",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-lighter to-dark-darker">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,215,0,0.1),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(0,123,255,0.1),transparent_50%)]" />

      {/* Header with Coins */}
      <header className="relative z-10 p-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-gold to-electric rounded-xl flex items-center justify-center text-2xl shadow-glow">
            ⚽
          </div>
          <div>
            <h1 className="text-2xl font-display font-bold text-gold text-glow">
              Football Routine
            </h1>
            <p className="text-gold/70 text-sm">
              Master your football knowledge
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {showInstallButton && (
            <button
              onClick={handleInstallClick}
              className="bg-gradient-to-r from-electric to-gold text-dark font-bold px-4 py-2 rounded-xl hover:scale-105 transition-transform shadow-glow text-sm"
            >
              📱 Install App
            </button>
          )}
          <div className="flex items-center gap-2 bg-card-glass rounded-xl px-4 py-2 border border-gold/20 shadow-glow">
            <span className="text-2xl coin-glow">🪙</span>
            <span className="text-gold font-bold font-display text-lg">
              {coins}
            </span>
            <span className="text-gold/70 text-sm">coins</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 pb-8">
        <div className="max-w-2xl mx-auto">
          {/* Welcome Section */}
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-gold via-electric to-gold-light mb-4">
              Welcome Back!
            </h2>
            <p className="text-dark-foreground/80 text-lg max-w-md mx-auto">
              Ready to master your football routine and earn some coins?
            </p>
          </div>

          {/* Menu Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {menuItems.map((item, index) => (
              <button
                key={index}
                onClick={item.onClick}
                className={`group relative overflow-hidden bg-gradient-to-br ${item.gradient} p-6 rounded-2xl transition-all duration-300 hover:scale-105 ${item.glow} hover:shadow-lg glow-button`}
              >
                {/* Background Pattern */}
                <div className="absolute inset-0 opacity-10">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,currentColor_1px,transparent_1px)] bg-[length:20px_20px]" />
                </div>

                {/* Content */}
                <div className="relative z-10 text-left">
                  <div className="flex items-center gap-4 mb-3">
                    <span className="text-4xl">{item.icon}</span>
                    <h3 className="text-xl font-display font-bold text-dark">
                      {item.title}
                    </h3>
                  </div>
                  <p className="text-dark/80 text-sm leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Hover Effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-transparent to-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </button>
            ))}
          </div>
        </div>
      </main>

      {/* Floating Football */}
      <div className="fixed bottom-8 right-8 w-16 h-16 bg-gradient-to-br from-gold to-electric rounded-full flex items-center justify-center text-3xl shadow-glow animate-bounce cursor-pointer hover:scale-110 transition-transform">
        ⚽
      </div>

      {/* Copyright Footer */}
      <footer className="relative z-10 p-6 text-center border-t border-border/20">
        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-4 text-sm">
            <button
              onClick={() => navigate("/privacy")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Privacy Policy
            </button>
            <span className="text-dark-foreground/40">•</span>
            <button
              onClick={() => navigate("/terms")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Terms of Service
            </button>
          </div>
          <p className="text-dark-foreground/60 text-sm">
            © Copyright owned by abatynawy
          </p>
        </div>
      </footer>
    </div>
  );
}
