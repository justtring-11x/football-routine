import { useNavigate } from "react-router-dom";

export default function TermsOfService() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-lighter to-dark-darker">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,123,255,0.1),transparent_50%)]" />

      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-gold hover:text-gold-light transition-colors"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          Back
        </button>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-electric to-gold rounded-xl flex items-center justify-center text-xl">
            📋
          </div>
          <h1 className="text-xl font-display font-bold text-gold">
            Terms of Service
          </h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 pb-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-card-glass rounded-2xl p-8 border border-border/50 shadow-card-soft">
            <div className="prose prose-invert max-w-none">
              <h2 className="text-3xl font-display font-bold text-gold mb-6">
                Terms of Service for Football Routine
              </h2>

              <p className="text-dark-foreground/80 mb-6">
                <strong>Effective Date:</strong>{" "}
                {new Date().toLocaleDateString()}
              </p>

              <div className="space-y-8">
                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    1. Acceptance of Terms
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      By accessing and using Football Routine (the "App"), you
                      accept and agree to be bound by the terms and provision of
                      this agreement. If you do not agree to abide by the above,
                      please do not use this service.
                    </p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    2. Description of Service
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      Football Routine is a web-based football knowledge game
                      that includes:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>
                        Multiple levels of football trivia questions (Rookie to
                        Legend)
                      </li>
                      <li>A virtual coin system for game progression</li>
                      <li>
                        Power-ups and items available for purchase with virtual
                        coins
                      </li>
                      <li>Progress tracking and level unlocking system</li>
                      <li>Local data storage for game progress</li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    3. User Conduct
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>You agree to use the App in accordance with:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>All applicable laws and regulations</li>
                      <li>These Terms of Service</li>
                      <li>Good sportsmanship and fair play principles</li>
                    </ul>
                    <p>You agree NOT to:</p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>
                        Attempt to cheat, hack, or manipulate the game mechanics
                      </li>
                      <li>
                        Reverse engineer or attempt to extract source code
                      </li>
                      <li>
                        Use the App for any illegal or unauthorized purpose
                      </li>
                      <li>Interfere with or disrupt the App's functionality</li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    4. Virtual Currency and Items
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      The virtual coins and items in Football Routine have no
                      real-world monetary value and cannot be exchanged for real
                      currency or transferred outside the App. Virtual coins
                      are:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Earned through gameplay achievements</li>
                      <li>
                        Used solely within the App for purchasing power-ups
                      </li>
                      <li>
                        Stored locally on your device with no external value
                      </li>
                      <li>
                        Subject to loss if you clear your browser data or reset
                        the game
                      </li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    5. Intellectual Property
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      Football Routine, including all content, features, and
                      functionality, is owned by abatynawy and is protected by
                      copyright and other intellectual property laws.
                    </p>
                    <p>
                      You are granted a limited, non-exclusive, non-transferable
                      license to use the App for personal, non-commercial
                      purposes.
                    </p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    6. Disclaimer of Warranties
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      The App is provided "as is" and "as available" without any
                      warranties of any kind, either express or implied. We do
                      not warrant that:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>The App will meet your specific requirements</li>
                      <li>
                        The App will be uninterrupted, timely, secure, or
                        error-free
                      </li>
                      <li>
                        Any defects in the App will be corrected within a
                        specific timeframe
                      </li>
                    </ul>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    7. Limitation of Liability
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      In no event shall abatynawy be liable for any direct,
                      indirect, incidental, special, consequential, or punitive
                      damages arising out of your use of the App.
                    </p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    8. Data and Privacy
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      Your privacy is important to us. Please review our Privacy
                      Policy, which also governs your use of the App, to
                      understand our practices regarding data collection and
                      storage.
                    </p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    9. Modifications to Terms
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      We reserve the right to modify these Terms of Service at
                      any time. Changes will be effective immediately upon
                      posting. Your continued use of the App constitutes
                      acceptance of any modifications.
                    </p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    10. Termination
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      You may discontinue use of the App at any time. abatynawy
                      reserves the right to suspend or terminate access to the
                      App for any reason, including violation of these Terms of
                      Service.
                    </p>
                  </div>
                </section>

                <section>
                  <h3 className="text-xl font-display font-bold text-gold mb-4">
                    11. Ownership and Proprietary Rights
                  </h3>
                  <div className="text-dark-foreground/80 space-y-3">
                    <p>
                      Football Routine is the exclusive intellectual property of
                      abatynawy. All rights, title, and interest in and to the
                      App, including but not limited to:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>
                        Source code, algorithms, and software architecture
                      </li>
                      <li>User interface design and visual elements</li>
                      <li>
                        Game mechanics, level design, and question content
                      </li>
                      <li>
                        Virtual currency system and game progression logic
                      </li>
                      <li>Branding, logos, and creative assets</li>
                    </ul>
                    <p>
                      are owned exclusively by abatynawy. This application was
                      created, developed, and is maintained by abatynawy as the
                      sole owner and creator.
                    </p>
                  </div>
                </section>
              </div>

              <div className="mt-8 p-4 bg-dark-lighter rounded-xl border border-electric/20">
                <p className="text-center text-electric font-medium">
                  Football Routine - Created and owned by abatynawy. Thank you
                  for using the app responsibly!
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Copyright Footer */}
      <footer className="relative z-10 p-6 text-center border-t border-border/20">
        <p className="text-dark-foreground/60 text-sm">
          © Copyright owned by abatynawy
        </p>
      </footer>
    </div>
  );
}
