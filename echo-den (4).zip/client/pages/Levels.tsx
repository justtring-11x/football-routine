import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Levels() {
  const navigate = useNavigate();
  const [coins, setCoins] = useState(0);
  const [unlockedLevels, setUnlockedLevels] = useState(1);

  useEffect(() => {
    const savedCoins = localStorage.getItem("footballQuizCoins");
    if (savedCoins) {
      setCoins(parseInt(savedCoins, 10));
    }

    const savedUnlockedLevels = localStorage.getItem(
      "footballRoutineUnlockedLevels",
    );
    if (savedUnlockedLevels) {
      setUnlockedLevels(parseInt(savedUnlockedLevels, 10));
    }
  }, []);

  const levels = [
    {
      id: 1,
      title: "Rookie",
      description: "Basic football knowledge",
      questions: 10,
      difficulty: "Easy",
      unlocked: true,
      color: "from-green-500 to-green-600",
      icon: "🌱",
    },
    {
      id: 2,
      title: "Amateur",
      description: "Club-level football facts",
      questions: 10,
      difficulty: "Easy-Medium",
      unlocked: unlockedLevels >= 2,
      color: "from-blue-500 to-blue-600",
      icon: "⚽",
    },
    {
      id: 3,
      title: "Professional",
      description: "League and tournament knowledge",
      questions: 10,
      difficulty: "Medium",
      unlocked: unlockedLevels >= 3,
      color: "from-gold to-gold-light",
      icon: "🏆",
    },
    {
      id: 4,
      title: "Expert",
      description: "Advanced football history",
      questions: 10,
      difficulty: "Hard",
      unlocked: unlockedLevels >= 4,
      color: "from-purple-500 to-purple-600",
      icon: "🔥",
    },
    {
      id: 5,
      title: "Legend",
      description: "Master of football knowledge",
      questions: 10,
      difficulty: "Expert",
      unlocked: unlockedLevels >= 5,
      color: "from-electric to-electric-light",
      icon: "👑",
    },
  ];

  const comingSoonLevels = [
    { title: "World Cup Master", icon: "🌍" },
    { title: "Champions League Elite", icon: "🌟" },
    { title: "Historical Genius", icon: "📚" },
  ];

  const handleLevelSelect = (levelId: number) => {
    if (levels[levelId - 1].unlocked) {
      navigate(`/quiz/${levelId}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-lighter to-dark-darker">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,215,0,0.1),transparent_50%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(0,123,255,0.1),transparent_50%)]" />

      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-gold hover:text-gold-light transition-colors"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          Back
        </button>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-gold to-electric rounded-xl flex items-center justify-center text-xl">
              🏟️
            </div>
            <h1 className="text-xl font-display font-bold text-gold">
              Select Level
            </h1>
          </div>
          <div className="flex items-center gap-2 bg-card-glass rounded-xl px-4 py-2 border border-gold/20">
            <span className="text-2xl coin-glow">🪙</span>
            <span className="text-gold font-bold">{coins}</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 pb-8">
        <div className="max-w-4xl mx-auto">
          {/* Intro */}
          <div className="text-center mb-8">
            <h2 className="text-3xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-gold via-electric to-gold-light mb-4">
              Choose Your Challenge
            </h2>
            <p className="text-dark-foreground/80">
              Each level has 10 questions. Complete levels to unlock the next
              challenge!
            </p>
          </div>

          {/* Available Levels */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {levels.map((level) => (
              <button
                key={level.id}
                onClick={() => handleLevelSelect(level.id)}
                disabled={!level.unlocked}
                className={`relative overflow-hidden p-6 rounded-2xl transition-all duration-300 ${
                  level.unlocked
                    ? `bg-gradient-to-br ${level.color} hover:scale-105 shadow-glow cursor-pointer`
                    : "bg-card border border-border/50 opacity-50 cursor-not-allowed"
                }`}
              >
                {/* Level Number Badge */}
                <div className="absolute top-4 right-4 w-8 h-8 bg-dark/30 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  {level.id}
                </div>

                {/* Lock Icon for Locked Levels */}
                {!level.unlocked && (
                  <div className="absolute inset-0 flex items-center justify-center bg-dark/50 rounded-2xl">
                    <div className="text-4xl">🔒</div>
                  </div>
                )}

                <div className="text-center">
                  <div className="text-4xl mb-3">{level.icon}</div>
                  <h3 className="text-xl font-display font-bold text-dark mb-2">
                    {level.title}
                  </h3>
                  <p className="text-dark/80 text-sm mb-3">
                    {level.description}
                  </p>
                  <div className="space-y-1">
                    <div className="text-dark/70 text-xs">
                      {level.questions} Questions
                    </div>
                    <div className="text-dark/70 text-xs font-medium">
                      {level.difficulty}
                    </div>
                  </div>
                </div>

                {level.unlocked && (
                  <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-transparent to-white/10 opacity-0 hover:opacity-100 transition-opacity duration-300" />
                )}
              </button>
            ))}
          </div>

          {/* Coming Soon Section */}
          <div className="bg-card-glass rounded-2xl p-8 border border-border/50 shadow-card-soft">
            <h3 className="text-2xl font-display font-bold text-gold text-center mb-6">
              🚀 More Levels Coming Soon!
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {comingSoonLevels.map((level, index) => (
                <div
                  key={index}
                  className="p-4 bg-dark-lighter rounded-xl text-center border border-border/30"
                >
                  <div className="text-3xl mb-2">{level.icon}</div>
                  <div className="text-sm text-dark-foreground/70 font-medium">
                    {level.title}
                  </div>
                </div>
              ))}
            </div>
            <p className="text-center text-dark-foreground/60 text-sm mt-6">
              We're working on even more challenging levels! Stay tuned for
              updates.
            </p>
          </div>

          {/* Progress Section */}
          <div className="mt-8 bg-card-glass rounded-xl p-6 border border-border/50">
            <h4 className="text-lg font-display font-bold text-gold mb-4 text-center">
              Your Progress
            </h4>
            <div className="flex items-center justify-center gap-2 mb-4">
              <span className="text-dark-foreground/70">Level Progress:</span>
              <span className="text-gold font-bold">
                {unlockedLevels} / {levels.length}
              </span>
            </div>
            <div className="w-full bg-dark-lighter rounded-full h-3">
              <div
                className="bg-gradient-to-r from-gold to-electric h-3 rounded-full transition-all duration-500"
                style={{
                  width: `${(unlockedLevels / levels.length) * 100}%`,
                }}
              />
            </div>
          </div>
        </div>
      </main>

      {/* Copyright Footer */}
      <footer className="relative z-10 p-6 text-center border-t border-border/20">
        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-4 text-sm">
            <button
              onClick={() => navigate("/privacy")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Privacy Policy
            </button>
            <span className="text-dark-foreground/40">•</span>
            <button
              onClick={() => navigate("/terms")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Terms of Service
            </button>
          </div>
          <p className="text-dark-foreground/60 text-sm">
            © Copyright owned by abatynawy
          </p>
        </div>
      </footer>
    </div>
  );
}
