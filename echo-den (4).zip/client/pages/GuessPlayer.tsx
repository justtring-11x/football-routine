import { useNavigate } from "react-router-dom";

export default function GuessPlayer() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark via-dark-lighter to-dark-darker">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,123,255,0.1),transparent_50%)]" />

      {/* Header */}
      <header className="relative z-10 p-6 flex justify-between items-center">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-gold hover:text-gold-light transition-colors"
        >
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M15 19l-7-7 7-7"
            />
          </svg>
          Back
        </button>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-electric to-gold rounded-xl flex items-center justify-center text-xl">
            ⚽
          </div>
          <h1 className="text-xl font-display font-bold text-gold">
            Guess the Player
          </h1>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 pb-8">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-card-glass rounded-2xl p-12 border border-border/50 shadow-card-soft">
            <div className="text-8xl mb-6">🚧</div>
            <h2 className="text-3xl font-display font-bold text-gold mb-4">
              Coming Soon!
            </h2>
            <p className="text-dark-foreground/80 text-lg mb-8 max-w-md mx-auto">
              We're working hard to bring you the most exciting player guessing
              experience. Test your knowledge of football legends and their
              career journeys!
            </p>

            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3 p-4 bg-dark-lighter rounded-xl">
                <span className="text-2xl">📸</span>
                <span className="text-dark-foreground">
                  Player photos and career info
                </span>
              </div>
              <div className="flex items-center gap-3 p-4 bg-dark-lighter rounded-xl">
                <span className="text-2xl">🏆</span>
                <span className="text-dark-foreground">
                  Club history challenges
                </span>
              </div>
              <div className="flex items-center gap-3 p-4 bg-dark-lighter rounded-xl">
                <span className="text-2xl">🪙</span>
                <span className="text-dark-foreground">
                  Earn coins for correct guesses
                </span>
              </div>
            </div>

            <button
              onClick={() => navigate("/levels")}
              className="bg-gradient-to-r from-electric to-gold text-dark font-bold py-3 px-8 rounded-xl hover:scale-105 transition-transform shadow-glow-electric"
            >
              Try Regular Routine Instead
            </button>
          </div>
        </div>
      </main>

      {/* Copyright Footer */}
      <footer className="relative z-10 p-6 text-center border-t border-border/20">
        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-4 text-sm">
            <button
              onClick={() => navigate("/privacy")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Privacy Policy
            </button>
            <span className="text-dark-foreground/40">•</span>
            <button
              onClick={() => navigate("/terms")}
              className="text-dark-foreground/60 hover:text-gold transition-colors"
            >
              Terms of Service
            </button>
          </div>
          <p className="text-dark-foreground/60 text-sm">
            © Copyright owned by abatynawy
          </p>
        </div>
      </footer>
    </div>
  );
}
