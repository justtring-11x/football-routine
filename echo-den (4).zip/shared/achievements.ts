export interface PlayerStats {
  routinesCompleted: number;
  perfectScores: number;
  totalCoinsEarned: number;
  maxStreak: number;
  levelsUnlocked: number;
  currentStreak: number;
}

export const getPlayerStats = (): PlayerStats => {
  const savedStats = localStorage.getItem("footballRoutineStats");
  if (savedStats) {
    return JSON.parse(savedStats);
  }
  return {
    routinesCompleted: 0,
    perfectScores: 0,
    totalCoinsEarned: 0,
    maxStreak: 0,
    levelsUnlocked: 1,
    currentStreak: 0,
  };
};

export const updatePlayerStats = (updates: Partial<PlayerStats>) => {
  const currentStats = getPlayerStats();
  const newStats = { ...currentStats, ...updates };
  localStorage.setItem("footballRoutineStats", JSON.stringify(newStats));
  return newStats;
};

export const addCoinsToTotal = (coinsEarned: number) => {
  const stats = getPlayerStats();
  return updatePlayerStats({
    totalCoinsEarned: stats.totalCoinsEarned + coinsEarned,
  });
};

export const completeRoutine = (score: number, totalQuestions: number) => {
  const stats = getPlayerStats();
  const isPerfect = score === totalQuestions;

  return updatePlayerStats({
    routinesCompleted: stats.routinesCompleted + 1,
    perfectScores: stats.perfectScores + (isPerfect ? 1 : 0),
    currentStreak: 0, // Reset streak at end of routine
  });
};

export const updateStreak = (isCorrect: boolean) => {
  const stats = getPlayerStats();
  const newStreak = isCorrect ? stats.currentStreak + 1 : 0;
  const newMaxStreak = Math.max(stats.maxStreak, newStreak);

  return updatePlayerStats({
    currentStreak: newStreak,
    maxStreak: newMaxStreak,
  });
};

export const updateUnlockedLevels = (level: number) => {
  const stats = getPlayerStats();
  if (level > stats.levelsUnlocked) {
    return updatePlayerStats({
      levelsUnlocked: level,
    });
  }
  return stats;
};
