# Football Routine - Vercel Deployment Guide

This guide explains how to deploy your Football Routine app to Vercel.

## 🚀 Quick Deploy

### Option 1: Deploy from GitHub (Recommended)

1. Push your code to a GitHub repository
2. Go to [Vercel](https://vercel.com)
3. Connect your GitHub account
4. Import your repository
5. Vercel will auto-detect the settings

### Option 2: Deploy with Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Follow the prompts
```

## ⚙️ Deployment Configuration

Your app is pre-configured with:

### `vercel.json`

- ✅ SPA routing for React Router
- ✅ API routes mapping
- ✅ PWA service worker headers
- ✅ Manifest.json headers

### Build Settings

- **Build Command**: `npm run build:client`
- **Output Directory**: `dist/spa`
- **Node.js Version**: 18.x (recommended)

### API Routes

- `/api/demo` - Demo endpoint
- `/api/ping` - Health check

## 🎯 Features Included

- ✅ **Progressive Web App (PWA)**
- ✅ **Offline Support** with Service Worker
- ✅ **Install on Home Screen**
- ✅ **Responsive Design**
- ✅ **5 Football Knowledge Levels**
- ✅ **Achievements System**
- ✅ **Coin Shop with Power-ups**
- ✅ **Local Storage Persistence**

## 🔧 Environment Variables

No environment variables are required for basic deployment.

## 📱 PWA Features

After deployment, users can:

- Install the app on their home screen
- Use offline with cached content
- See the football icon in their app drawer

## 🌐 Custom Domain

To add a custom domain:

1. Go to your Vercel dashboard
2. Select your project
3. Go to "Settings" → "Domains"
4. Add your custom domain

## 🎮 App Structure

```
/                    # Homepage with welcome screen
/levels             # Level selection (Rookie to Legend)
/quiz/:levelId      # Quiz gameplay
/guess-player       # Player guessing game (placeholder)
/coins              # Achievements and coin shop
/settings           # App settings
/privacy            # Privacy policy
/terms              # Terms of service
```

## 🏆 Ready for Production

Your Football Routine app is production-ready with:

- Modern React 18 + TypeScript
- Vite for fast builds
- TailwindCSS for styling
- PWA capabilities
- Achievement tracking
- Coin economy system

Enjoy your deployed Football Routine app! ⚽🎮
